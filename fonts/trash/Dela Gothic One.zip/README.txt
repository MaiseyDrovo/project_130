DelaGothic is a flat, very thick Gothic body. Its stability and strength make it ideal for use on posters and packaging.

To contribute to the project, visit [github.com/syakuzen/DelaGothic](https://github.com/syakuzen/DelaGothic)